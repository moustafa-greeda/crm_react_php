import React, { useContext } from "react";
import { AuthContext } from "./AuthContext";
import {
  FaCalendarAlt,
  FaUsers,
  FaEnvelope,
  FaTasks,
  FaCog,
  FaTachometerAlt
} from "react-icons/fa";
import { Link } from "react-router-dom";
import "./Sidebar.css";

const Sidebar = () => {
  const { user } = useContext(AuthContext);
  const { role } = user; // يمكن أن تكون "admin" أو "user"

  return (
    <aside className="sidebar">
      <div className="logo">
        <img src="logo.png" alt="ZBOOMA Logo" className="logo-image" />
        <span>ZBOOMA</span>
      </div>
      <ul className="menu">
        {/* الروابط العامة */}
        <li className="menu-item">
          <Link to="/dashboard">
            <FaTachometerAlt className="menu-icon" />
            Dashboard
          </Link>
        </li>
        <li className="menu-item">
          <Link to="/calendar">
            <FaCalendarAlt className="menu-icon" />
            Calendar
          </Link>
        </li>
        <li className="menu-item">
          <Link to="/messages">
            <FaEnvelope className="menu-icon" />
            Messages
          </Link>
        </li>
        <li className="menu-item">
          <Link to="/tasks">
            <FaTasks className="menu-icon" />
            Tasks
          </Link>
        </li>

        {/* الروابط المخصصة للمسؤول فقط */}
        {role === "admin" && (
          <>
            <li className="menu-item">
              <Link to="/customers">
                <FaUsers className="menu-icon" />
                Customers
              </Link>
            </li>
            <li className="menu-item">
              <Link to="/settings">
                <FaCog className="menu-icon" />
                Settings
              </Link>
            </li>
          </>
        )}
      </ul>
    </aside>
  );
};

export default Sidebar;
